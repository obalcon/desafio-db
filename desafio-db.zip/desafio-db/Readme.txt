Readme 


1- Requisitos.
   
   1.1 Servidor Tomcat 9
   1.2 Java 8
   1.3 Eclipse ou otra ide 
   
2- Utilizar Sistema
  
   2.1 http://localhost:8080/desafio-db/  para acessar o sistema . 
      
      Os seguintes informações serão carregadas automaticamente  banco H2 
        Lista de restaurantes 
            Restaurante 1
            Restaurante 2
            Restaurante 3
            Restaurante 4
            Restaurante 5
            Restaurante 6
            Restaurante 7
        Lista de usuários do sistema.
        
             usuario1  - (Usuário que solicitou o software.)
             usuario2
             usuario3
             usuario4
        
    2.2 Sistema
    
        2.2.1 - Acessar a url http://localhost:8080/desafio-db/ e fazer login digitando um dos usuarios informados acima. 
                No caso o usuario1 é o usuário principal ele poderá obter o resultado da votção . 
                
        2.2.2 - Após o login é apresentada a tela de votação composta por um combobox com a lista de restaurantes previamente carregada . 
                Para votar somente é necessário escolher o restaurante e clicar em votar . 
        2.2.3 - Se o usuário logado for o usuario1 apresentara tambem o link "Fechar resultado".
                Ao clicar nesse link a pagina com o resultado da votaçõa será exibido . 
        2.2.4 - Link "sair" para voltar a tela de login.
   
3 -  Destacar 
     Sistema simples ,  utilizei sppring mvc , servidor tomcat com base H2.

4 - Melhorias. 
     Implementar : 
     Cadastro de usuário , 
     Cadastro de Restaurante.
     Bloqueio para no caso o usuairo principal queira fechar o resultado sem votar . 
     Necesidade de que todos os usuários tenham votado para poder exibir o resultado da votação . 
     
5-   O Desafio solicita a elaboração de teste integrados. 
     Na entrevista foi relatado que atualmente não estou resalizado essa tarefa. 
     A gente só faz teste unitário e teste funcional . 
     Mesmo assim tentei implementar os testes , mas não consegui fazer funcionar . 
     
        
