package com.desafiodb.spring.test;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.DefaultMockMvcBuilder;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.desafiodb.spring.pojo.UsuarioDTO;
import com.desafiodb.spring.pojo.VotoDTO;
import com.desafiodb.spring.test.config.MyWebConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = MyWebConfig.class)
public class PrincipalControllerTest {

    @Autowired
    private WebApplicationContext wac;

    private MockMvc mockMvc;

    @Before
    public void setup () {
        DefaultMockMvcBuilder builder = MockMvcBuilders.webAppContextSetup(this.wac);
        this.mockMvc = builder.build();
    }

    @Test
    public void testUsuLoginController() throws Exception {
   
    	mockMvc.perform(MockMvcRequestBuilders.post("/usuario")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("nome", "usuario1")
                .sessionAttr("usuario", new UsuarioDTO())
        )
                .andExpect(status().isMovedTemporarily())
                .andExpect(view().name("principal"))
                .andExpect(MockMvcResultMatchers.forwardedUrl("/principal"));
    }
    @Test
    public void testHomeController() throws Exception {
        ResultMatcher ok = MockMvcResultMatchers.status()
                                                .isOk();

        MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.get("/");
        this.mockMvc.perform(builder)
                    .andExpect(ok);

    }
    @Test
    public void testVotarController() throws Exception {
    	mockMvc.perform(MockMvcRequestBuilders.post("/usuario")
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .param("nomeRest", "Restaurante 1")
                .param("nomeVotante", "usuario1")
                .sessionAttr("usuario", new VotoDTO())
        )
                .andExpect(status().isMovedTemporarily())
                .andExpect(view().name("usuario"))
                .andExpect(MockMvcResultMatchers.forwardedUrl("/usuario"));

    }
    @Test
    public void testResultadoController() throws Exception {
    	
        ResultMatcher ok = MockMvcResultMatchers.status()
		                .isOk();
		
		MockHttpServletRequestBuilder builder = MockMvcRequestBuilders.get("/resultado");
		this.mockMvc.perform(builder)
		.andExpect(ok);

    }
}