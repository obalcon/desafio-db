package com.desafiodb.spring.test.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.desafiodb.spring.controller.PrincipalController;

	@EnableWebMvc
	@Configuration
	@Import(MyViewConfig.class)
	public class MyWebConfig extends WebMvcConfigurerAdapter {

	      

	    @Bean
	    public PrincipalController principalController () {
	        return new PrincipalController();
	    }

	    
}
