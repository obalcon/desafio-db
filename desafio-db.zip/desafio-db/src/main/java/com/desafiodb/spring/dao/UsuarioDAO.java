package com.desafiodb.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.desafiodb.spring.model.Usuario;

@Component
public class UsuarioDAO {
	@PersistenceContext
	private EntityManager em;
	
	public List<Usuario> getAllUsers() {
        TypedQuery<Usuario> query = em.createQuery(
        		"SELECT u FROM User u ORDER BY u.id", Usuario.class);
        return query.getResultList();
    }
	
	public Usuario getByLogin(Usuario usuario) {
        TypedQuery<Usuario> query = em.createQuery(
        		"SELECT u FROM Usuario u where u.nome ='" + usuario.getNome() +"'", Usuario.class);
        return query.getResultList().stream().findFirst().orElse(null);
    }
	
	@Transactional
	public void delete(int userId) {
		Usuario usuario = em.getReference(Usuario.class, userId);
		em.remove(usuario);
	}
	
	@Transactional
	public void save(Usuario usuario) {
		em.persist(usuario);
	}
}
