package com.desafiodb.spring.model; 

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Voto implements Serializable {
	
	
	private static final long serialVersionUID = -1;
	
	@Id
    @GeneratedValue
	private int idVoto;
	@Column
	private LocalDate  dataVoto;
	@Column
	private String nomeRest;
	@Column
	private String nomeVotante;
	
	
	
	public int getIdVoto() {
		return idVoto;
	}
	public void setIdVoto(int idVoto) {
		this.idVoto = idVoto;
	}
	public LocalDate  getDataVoto() {
		return dataVoto;
	}
	public void setDataVoto(LocalDate  dataVoto) {
		this.dataVoto = dataVoto;
	}
	public String getNomeRest() {
		return nomeRest;
	}
	public void setNomeRest(String nomeRest) {
		this.nomeRest = nomeRest;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getNomeVotante() {
		return nomeVotante;
	}
	public void setNomeVotante(String nomeVotante) {
		this.nomeVotante = nomeVotante;
	}
	
    
}
