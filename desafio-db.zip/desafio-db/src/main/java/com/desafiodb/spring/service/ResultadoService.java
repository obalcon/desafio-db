package com.desafiodb.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.desafiodb.spring.dao.ResultadoDAO;
import com.desafiodb.spring.model.Resultado;
import com.desafiodb.spring.pojo.ResultadoSemDTO;


@Service
public class ResultadoService {
	
	@Autowired
    private ResultadoDAO resultDAO;
	
	
	public List<Resultado> getAllUsers() {
		return resultDAO.getAllResultados();
	}
	
	public List<Resultado> getByNome(Resultado res) {
		return resultDAO.getByNome(res);
	}
	
	public void save(Resultado aUser) {
		resultDAO.save(aUser);
	}
	
	public void delete(int userId) {
		resultDAO.delete(userId);
	}
	public Resultado getExisteResultSem(ResultadoSemDTO res) {
		return resultDAO.getExisteResultSem(res);
	}
	
	

}
