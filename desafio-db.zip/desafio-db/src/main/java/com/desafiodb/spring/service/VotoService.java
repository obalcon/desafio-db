package com.desafiodb.spring.service;


import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.desafiodb.spring.dao.VotoDAO;
import com.desafiodb.spring.model.Voto;
import com.desafiodb.spring.pojo.ResultadoDTO;


@Service
public class VotoService {

	@Autowired
    private VotoDAO votoDAO;
	
	
	public List<Voto> getAllVotos() {
		return votoDAO.getAllVotos();
	}
	
	public List<Voto> getVotoByData(Voto vot) {
		return votoDAO.getVotoByData(vot);
	}
	
	public Voto getVotoByDataUsu(Voto vot) {
		return votoDAO.getVotoByDataUsu(vot);
	}
	public List<Voto> getVotoByRest(Voto vot) {
		return votoDAO.getVotoByRest(vot);
	}
	public List<Voto> getVotoByVotante(Voto vot) {
		return votoDAO.getVotoByVotante(vot);
	}
	public void save(Voto vot) {
		votoDAO.save(vot);
	}
	
	public void delete(int votId) {
		votoDAO.delete(votId);
	}
	public List<ResultadoDTO>getEscolhaHoje(LocalDate hoje){
		return votoDAO.getEscolhaHoje(hoje);
	}

}
