package com.desafiodb.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.desafiodb.spring.dao.UsuarioDAO;
import com.desafiodb.spring.model.Usuario;


@Service
public class UsuarioService {
	
	@Autowired
    private UsuarioDAO userDAO;
	
	
	public List<Usuario> getAllUsers() {
		return userDAO.getAllUsers();
	}
	public Usuario getByLogin(Usuario usuario) {
		return userDAO.getByLogin(usuario);
	}
	public void save(Usuario aUsuario) {
		userDAO.save(aUsuario);
	}
	
	public void delete(int usuarioId) {
		userDAO.delete(usuarioId);
	}
	
	

}
