package com.desafiodb.spring.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.desafiodb.spring.model.Restaurante;

@Component
public class RestauranteDAO {
	
	@PersistenceContext
	private EntityManager em;
	
	public List<Restaurante> getAllRestaurante() {
        TypedQuery<Restaurante> query = em.createQuery(
        		"SELECT r FROM Restaurante r ORDER BY r.idRes", Restaurante.class);
        return query.getResultList();
    }
	
	public List<Restaurante> getByNome(Restaurante res) {
        TypedQuery<Restaurante> query = em.createQuery(
        		"SELECT r FROM Restaurante r where r.nomeRes =" + res.getNomeRes() + "ORDER BY r.idRes", Restaurante.class);
        return query.getResultList();
    }
	
	@Transactional
	public void delete(int resId) {
		Restaurante  res = em.getReference(Restaurante.class, resId);
		em.remove(res);
	}
	
	@Transactional
	public void save(Restaurante res) {
		em.persist(res);
	}
	
	
	

}
