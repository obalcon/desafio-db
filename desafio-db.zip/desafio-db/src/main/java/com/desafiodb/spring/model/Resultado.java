package com.desafiodb.spring.model;

import java.io.Serializable;
import java.time.LocalDate;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Resultado implements Serializable {
	

	private static final long serialVersionUID = -1;
	
	@Id
    @GeneratedValue
	private int idResult;
	
	@Column
	private LocalDate dataResult;
	
	@Column	
	private String nomeGanhador;

	public String getNomeGanhador() {
		return nomeGanhador;
	}

	public void setNomeGanhador(String nomeGanhador) {
		this.nomeGanhador = nomeGanhador;
	}

	public int getIdResult() {
		return idResult;
	}

	public void setIdResult(int idResult) {
		this.idResult = idResult;
	}

	public LocalDate getDataResult() {
		return dataResult;
	}

	public void setDataResult(LocalDate dataResult) {
		this.dataResult = dataResult;
	}

}
