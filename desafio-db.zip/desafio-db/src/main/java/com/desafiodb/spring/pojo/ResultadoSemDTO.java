package com.desafiodb.spring.pojo;

import java.time.LocalDate;

public class ResultadoSemDTO {

		private LocalDate inico;
		
		private LocalDate fim;
		
	    private String nomeRest;
	    
		public LocalDate getInico() {
			return inico;
		}
		public void setInico(LocalDate inico) {
			this.inico = inico;
		}
		public LocalDate getFim() {
			return fim;
		}
		public void setFim(LocalDate fim) {
			this.fim = fim;
		}
		public String getNomeRest() {
			return nomeRest;
		}
		public void setNomeRest(String nomeRest) {
			this.nomeRest = nomeRest;
		}
	    
	    
}
