package com.desafiodb.spring.dao;



import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.desafiodb.spring.model.Voto;
import com.desafiodb.spring.pojo.ResultadoDTO;

@Component
public class VotoDAO {
	
	
	//@PersistenceContext
	@PersistenceContext(type = PersistenceContextType.EXTENDED)
	private EntityManager em;
	
	public List<Voto> getAllVotos() {
        TypedQuery<Voto> query = em.createQuery(
        		"SELECT v FROM Voto v ORDER BY r.idVoto", Voto.class);
        return query.getResultList();
    }
	
	public List<Voto> getVotoByRest(Voto voto) {
        TypedQuery<Voto> query = em.createQuery(
        		"SELECT v FROM Voto v where v.nomeRest =" + voto.getNomeRest() + "ORDER BY v.idVoto", Voto.class);
        return query.getResultList();
    }
	
	public List<Voto> getVotoByVotante(Voto voto) {
        TypedQuery<Voto> query = em.createQuery(
        		"SELECT v FROM Voto v where v.nomeVotante =" + voto.getNomeVotante() + "ORDER BY r.idVoto", Voto.class);
        return query.getResultList();
    }
	public List<Voto> getVotoByData(Voto voto) {
        TypedQuery<Voto> query = em.createQuery(
        		"SELECT v FROM Voto v where v.dataVoto =" + voto.getDataVoto() + "ORDER BY r.idVoto", Voto.class);
        return query.getResultList();
    }
	
	
	
	public Voto getVotoByDataUsu(Voto voto) {
	 	
        TypedQuery<Voto> query = em.createQuery(
        		"SELECT v FROM Voto v where v.dataVoto ='" + voto.getDataVoto()+ "' "
        				+ " AND v.nomeVotante = '"+  voto.getNomeVotante() +"'" , Voto.class);
        return query.getResultList().stream().findFirst().orElse(null);
    }
	
	@Transactional 
	public void delete(int idVoto) {
		Voto  res = em.getReference(Voto.class, idVoto);
		em.remove(res);
	}
	

	@Transactional
	public void save(Voto res) {
		em.persist(res);
	}
	
	@SuppressWarnings("unchecked")
	public List<ResultadoDTO> getEscolhaHoje (LocalDate hoje) {
	       Query query = em.createNativeQuery(
	    		   "SELECT v.nomeRest  ,count(v.nomeRest) quantidade  FROM voto v where v.dataVoto ='" + hoje + "' group by v.nomeRest order by quantidade desc ");
	   
	       
	       List<Object[]> result =  query.getResultList();
	        List <ResultadoDTO> listResult = new ArrayList<ResultadoDTO>();
	        for (Object[] c:result) {
	        	ResultadoDTO resDto = new ResultadoDTO();
	        	resDto.setNomeRest((String)c[0]);
	        	resDto.setQuantidade( ((BigInteger)c[1]).intValue());
	        	listResult.add(resDto);
	        }
	        return listResult;
	    }
	
	
}
