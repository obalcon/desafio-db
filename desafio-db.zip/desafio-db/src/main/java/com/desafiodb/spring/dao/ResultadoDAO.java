package com.desafiodb.spring.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.desafiodb.spring.model.Resultado;
import com.desafiodb.spring.pojo.ResultadoDTO;
import com.desafiodb.spring.pojo.ResultadoSemDTO;

@Component
public class ResultadoDAO {

	
	@PersistenceContext
	private EntityManager em;
	
	public List<Resultado> getAllResultados() {
        TypedQuery<Resultado> query = em.createQuery(
        		"SELECT r FROM Resultado r ORDER BY r.idResult", Resultado.class);
        return query.getResultList();
    }
	
	public List<Resultado> getByNome(Resultado res) {
        TypedQuery<Resultado> query = em.createQuery(
        		"SELECT r FROM Resultado r where r.nomeGanhador =" + res.getNomeGanhador() + "ORDER BY r.idResult", Resultado.class);
        return query.getResultList();
    }
	
	public Resultado getExisteResultSem(ResultadoSemDTO res) {
        TypedQuery<Resultado> query = em.createQuery(
        		"SELECT r FROM Resultado r where r.nomeGanhador ='" + res.getNomeRest() + "' and dataResult between '"+ res.getInico() +"' and '" + res.getFim()+"'" , Resultado.class);
        return query.getResultList().stream().findFirst().orElse(null);
	}

	@Transactional
	public void delete(int resId) {
		Resultado  res = em.getReference(Resultado.class, resId);
		em.remove(res);
	}
	
	@Transactional
	public void save(Resultado res) {
		em.persist(res);
	}
	
	
	
}
