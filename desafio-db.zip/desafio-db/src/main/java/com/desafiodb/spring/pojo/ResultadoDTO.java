package com.desafiodb.spring.pojo;

public class ResultadoDTO {
	
	private String nomeRest;
	
	private Integer quantidade;

	public String getNomeRest() {
		return nomeRest;
	}

	public void setNomeRest(String nomeRest) {
		this.nomeRest = nomeRest;
	}

	public Integer getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	

}
