package com.desafiodb.spring.controller;

import java.text.DateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.time.temporal.WeekFields;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.desafiodb.spring.model.Restaurante;
import com.desafiodb.spring.model.Resultado;
import com.desafiodb.spring.model.Usuario;
import com.desafiodb.spring.model.Voto;
import com.desafiodb.spring.pojo.ResultadoDTO;
import com.desafiodb.spring.pojo.ResultadoSemDTO;
import com.desafiodb.spring.pojo.UsuarioDTO;
import com.desafiodb.spring.pojo.VotoDTO;
import com.desafiodb.spring.service.RestauranteService;
import com.desafiodb.spring.service.ResultadoService;
import com.desafiodb.spring.service.UsuarioService;
import com.desafiodb.spring.service.VotoService;

@Controller
public class PrincipalController {

	
	@Autowired
    private UsuarioService usuService;
	
	@Autowired
    private RestauranteService restService;
	
	@Autowired
    private VotoService votoService;
	
	@Autowired
    private ResultadoService resultService;
	
	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		System.out.println("Pagina Principal Chamada, locale = " + locale);
		LocalDate hoje = LocalDate.now();
		
		// primer dia da semana 
		DayOfWeek primerDiaSem = WeekFields.of(Locale.getDefault()).getFirstDayOfWeek();
		LocalDate comecoSemanCorrent = hoje.with(TemporalAdjusters.previousOrSame(primerDiaSem));

		/*
		 * Registrando um resultado para poder fazer um teste .
		 */
		 Resultado resu = new Resultado();
		 resu.setNomeGanhador("Restaurante 1");
		 resu.setDataResult(comecoSemanCorrent);
		 resultService.save(resu);
		
        LocalDate data = LocalDate.now();

       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        String dataF = data.format(formatter);
		model.addAttribute("serverDate", dataF);
		return "principal";
	}

	@RequestMapping(value = "/usuario", method = RequestMethod.POST)
	public String usuario(@Validated UsuarioDTO usuarioDTO, Model model) {
		System.out.println("Pagina usuario Chamada");
		System.out.println(usuarioDTO.getNome());
		String retorno = new String();
		
		Usuario usuario = new Usuario();
		usuario.setNome(usuarioDTO.getNome());
		
		/* verificar se usuario existe */
		Usuario usuarioAux = usuService.getByLogin(usuario);
		List<Restaurante> listaRes =  restService.getAllRestaurante();
		
		model.addAttribute("nome", usuario.getNome());

		if (usuarioAux != null) {
			model.addAttribute("listaRes",listaRes);
			if("usuario1".contentEquals(usuarioAux.getNome())) {
				model.addAttribute("admin","sim");
			}else {
				model.addAttribute("admin","nao");
			}
			retorno = "usuario";
		}else {
			model.addAttribute("mensagem", "Usuario não encontrado");	
			retorno = "principal";
		}
		return retorno;
	}
	@RequestMapping(value = "/votar", method = RequestMethod.POST)
	public String votar(@Validated VotoDTO votoDTO, Model model) {
		System.out.println("Método votar");
		LocalDate hoje = LocalDate.now();
		
		Voto voto = new Voto();
		voto.setNomeRest(votoDTO.getNomeRest());
		voto.setNomeVotante(votoDTO.getNomeVotante());
		voto.setDataVoto(hoje);
		
		List<Restaurante> listaRes =  restService.getAllRestaurante();
		try {
			// primer dia da semana 
			DayOfWeek primerDiaSem = WeekFields.of(Locale.getDefault()).getFirstDayOfWeek();
			LocalDate comecoSemanCorrent = hoje.with(TemporalAdjusters.previousOrSame(primerDiaSem));

			// ultimo dia da semana 
			DayOfWeek ultimoDiaSemana = primerDiaSem.plus(6); // or minus(1)
			LocalDate finalSemana = hoje.with(TemporalAdjusters.nextOrSame(ultimoDiaSemana));

			 ResultadoSemDTO resuDTO = new ResultadoSemDTO();
			 resuDTO.setNomeRest(voto.getNomeRest());
			 resuDTO.setInico(comecoSemanCorrent);
			 resuDTO.setFim(finalSemana);
			 //Estória  2 
			 Resultado resultAux = resultService.getExisteResultSem(resuDTO);
			 
			 if(resultAux != null) {
				 model.addAttribute("mensagem","O restaurante "+ voto.getNomeRest() +" já foi escolhido esta semana . \n Por favor escolha outro "); model.addAttribute("listaRes",listaRes);
			 
			 }else {
				 //Estória 1
				 Voto votoAux = votoService.getVotoByDataUsu(voto);
				 if(votoAux == null) {
			        votoService.save(voto);
					model.addAttribute("mensagem", "Voto registrado");	
				 }else {
					 model.addAttribute("mensagem","Seu voto já foi registrado no dia de hoje"); model.addAttribute("listaRes",listaRes);
				 }
			 }
			 model.addAttribute("nome",voto.getNomeVotante()); 
			 model.addAttribute("listaRes",listaRes); 
		}catch(Exception e) { model.addAttribute("mensagem",
				  "Erro ao inserir seu voto"); model.addAttribute("listaRes",listaRes);
				  model.addAttribute("nome",voto.getNomeVotante()); }
		return "usuario";
	}
	@RequestMapping(value = "/resultado", method = RequestMethod.GET)
	public String resultado(@Validated Voto voto, Model model) {
		System.out.println("Método Retorna resultado votação");
		LocalDate hoje = LocalDate.now();
	    
		try {
			//Estória 3 
			List<ResultadoDTO> listResult = votoService.getEscolhaHoje(hoje);
			Resultado res = new Resultado();
			res.setDataResult(hoje);
			res.setNomeGanhador(listResult.get(0).getNomeRest());
			res.setDataResult(hoje);
			
			//Salvar Resultado
			
			resultService.save(res);
			model.addAttribute("listaResultado",listResult);
		
		  }catch(Exception e) {
			  model.addAttribute("mensagem","Erro ao exibir resultado"); }
		 
		return "resultado";
	}
	
	
}
