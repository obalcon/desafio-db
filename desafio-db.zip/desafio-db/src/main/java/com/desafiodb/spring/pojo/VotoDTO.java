package com.desafiodb.spring.pojo;

public class VotoDTO {

	 private String nomeRest;
	 private String nomeVotante;
	 
	 
	public String getNomeRest() {
		return nomeRest;
	}
	public void setNomeRest(String nomeRest) {
		this.nomeRest = nomeRest;
	}
	public String getNomeVotante() {
		return nomeVotante;
	}
	public void setNomeVotante(String nomeVotante) {
		this.nomeVotante = nomeVotante;
	}
	 
	 
}
