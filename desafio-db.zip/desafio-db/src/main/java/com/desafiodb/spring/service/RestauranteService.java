package com.desafiodb.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.desafiodb.spring.dao.RestauranteDAO;
import com.desafiodb.spring.model.Restaurante;

@Service
public class RestauranteService {

	@Autowired
    private RestauranteDAO restDAO;
	
	
	public List<Restaurante> getAllRestaurante() {
		return restDAO.getAllRestaurante();
	}
	public List<Restaurante> getByNome(Restaurante res) {
		return restDAO.getByNome(res);
	}
	
	public void save(Restaurante aRest) {
		restDAO.save(aRest);
	}
	
	public void delete(int resId) {
		restDAO.delete(resId);
	}
	
	
}
