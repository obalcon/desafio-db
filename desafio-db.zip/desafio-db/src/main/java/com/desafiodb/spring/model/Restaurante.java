package com.desafiodb.spring.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Restaurante  implements Serializable{

	private static final long serialVersionUID = -1;
	@Id
    @GeneratedValue
	private int idRes;
	
	@Column
	private String nomeRes;
	
	public int getIdRes() {
		return idRes;
	}
	public void setIdRes(int idRes) {
		this.idRes = idRes;
	}
	public String getNomeRes() {
		return nomeRes;
	}
	public void setNomeRes(String nomeRes) {
		this.nomeRes = nomeRes;
	}
	
	

}
