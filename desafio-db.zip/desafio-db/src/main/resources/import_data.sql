INSERT INTO usuario values (1, 'usuario1');
INSERT INTO usuario values (2, 'usuario2');
INSERT INTO usuario values (3, 'usuario3');
INSERT INTO usuario values (4, 'usuario4');

INSERT INTO restaurante values(1,'Restaurante 1');
INSERT INTO restaurante values(2,'Restaurante 2');
INSERT INTO restaurante values(3,'Restaurante 3');
INSERT INTO restaurante values(4,'Restaurante 4');
INSERT INTO restaurante values(5,'Restaurante 5');
INSERT INTO restaurante values(6,'Restaurante 6');
INSERT INTO restaurante values(7,'Restaurante 7');



